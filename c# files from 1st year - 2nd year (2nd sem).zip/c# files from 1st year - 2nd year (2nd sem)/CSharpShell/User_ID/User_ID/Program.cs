﻿using System;

namespace User;

public static class Program
{
    public static void Main()
    {
        User user = new User();

        Console.Write("Enter your Email Address: ");
        string email = Console.ReadLine();

        user.Email = email;

        if (!string.IsNullOrEmpty(user.Email))
        {
            Console.WriteLine("Email Address: " + user.Email);
        }
    }
}

class User
{
    private string email;

    public string Email
    {
        get
        {
            return email;
        }

        set
        {
            if (IsValidEmail(value))
            {
                email = value;
            }
            else
            {
                Console.WriteLine("Error! Please enter a valid email address.");
            }
        }
    }

    private bool IsValidEmail(string email)
    {
        // Simple email validation logic
        return email.Contains("@") && email.Contains(".") && email.IndexOf("@") < email.LastIndexOf(".");
    }
}
