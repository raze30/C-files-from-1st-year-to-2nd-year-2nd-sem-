﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace OJTMonitoringSystem
{
    class Program
    {
        // Importing Windows API to hide console window
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool FreeConsole();

        // APIs for active window detection
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int GetWindowText(IntPtr hwnd, StringBuilder lpString, int cch);

        // Data for logs and users
        static Dictionary<string, (string Password, string Name, string School, int Age, string Course, int YearLevel)> users = new();
        static List<string> logInOutRecords = new();
        static List<string> workActivityRecords = new();
        static string currentUser;

        static void Main(string[] args)
        {
            // Hide the console window at startup
            FreeConsole();

            // Initial Menu
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Welcome to OJT Monitoring System!");
                Console.WriteLine("1. Sign Up");
                Console.WriteLine("2. Log In");
                Console.WriteLine("3. Exit");
                Console.Write("Choose an option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        SignUp();
                        break;
                    case "2":
                        if (LogIn())
                        {
                            MainMenu();
                        }
                        break;
                    case "3":
                        Console.WriteLine("Goodbye!");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void SignUp()
        {
            Console.Clear();
            Console.WriteLine("Sign Up");

            Console.Write("Enter your school: ");
            string school = Console.ReadLine();

            Console.Write("Enter your full name: ");
            string fullName = Console.ReadLine();

            Console.Write("Enter your age: ");
            int age = int.Parse(Console.ReadLine());

            Console.Write("Enter your course: ");
            string course = Console.ReadLine();

            Console.Write("Enter your year level: ");
            int yearLevel = int.Parse(Console.ReadLine());

            Console.Write("Create a username: ");
            string username = Console.ReadLine();

            Console.Write("Create a password: ");
            string password = Console.ReadLine();

            users[username] = (password, fullName, school, age, course, yearLevel);
            Console.WriteLine("Sign-up successful! You can now log in.");
            Console.ReadLine();
        }

        static bool LogIn()
        {
            Console.Clear();
            Console.WriteLine("Log In");

            Console.Write("Enter your username: ");
            string username = Console.ReadLine();

            Console.Write("Enter your password: ");
            string password = Console.ReadLine();

            if (users.ContainsKey(username) && users[username].Password == password)
            {
                currentUser = username;
                Console.WriteLine("Log in successful! Welcome, " + users[username].Name);
                Console.ReadLine();
                return true;
            }

            Console.WriteLine("Invalid credentials. Please try again.");
            Console.ReadLine();
            return false;
        }

        static void MainMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Main Menu");
                Console.WriteLine("1. Manual Log In/Out");
                Console.WriteLine("2. Automated Log In/Out");
                Console.WriteLine("3. Manual Work Activity");
                Console.WriteLine("4. Automated Work Activity");
                Console.WriteLine("5. View Logs");
                Console.WriteLine("6. Log Out");
                Console.Write("Choose an option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ManualLogInOut();
                        break;
                    case "2":
                        AutomatedLogInOut();
                        break;
                    case "3":
                        ManualWorkActivity();
                        break;
                    case "4":
                        AutomatedWorkActivity();
                        break;
                    case "5":
                        ViewLogs();
                        break;
                    case "6":
                        currentUser = null;
                        Console.WriteLine("Logged out successfully.");
                        Console.ReadLine();
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void ManualLogInOut()
        {
            Console.Clear();
            Console.WriteLine("Manual Log In/Out");

            Console.Write("Enter 'in' for log in or 'out' for log out: ");
            string logType = Console.ReadLine();
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            if (logType == "in" || logType == "out")
            {
                logInOutRecords.Add($"[{timestamp}] {currentUser} logged {logType} manually.");
                Console.WriteLine("Log recorded successfully.");
            }
            else
            {
                Console.WriteLine("Invalid input.");
            }

            Console.ReadLine();
        }

        static void AutomatedLogInOut()
        {
            Console.Clear();
            Console.WriteLine("Automated Log In/Out");

            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            logInOutRecords.Add($"[{timestamp}] {currentUser} logged in/out automatically.");
            Console.WriteLine("Automated log recorded successfully.");
            Console.ReadLine();
        }

        static void ManualWorkActivity()
        {
            Console.Clear();
            Console.WriteLine("Manual Work Activity");

            Console.Write("Enter work activity: ");
            string activity = Console.ReadLine();
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            workActivityRecords.Add($"[{timestamp}] {currentUser}: {activity}");
            Console.WriteLine("Work activity recorded successfully.");
            Console.ReadLine();
        }

        static void AutomatedWorkActivity()
        {
            Console.Clear();
            Console.WriteLine("Automated Work Activity started. Tracking active windows...");
            Console.WriteLine("You can minimize or close this window to continue tracking in the background.");

            Thread backgroundThread = new Thread(() =>
            {
                while (true)
                {
                    const int nChars = 256;
                    StringBuilder Buff = new StringBuilder(nChars);
                    IntPtr handle = GetForegroundWindow();

                    if (GetWindowText(handle, Buff, nChars) > 0)
                    {
                        string activeWindow = Buff.ToString();
                        string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                        // Add to work activity records
                        workActivityRecords.Add($"[{timestamp}] {currentUser}: {activeWindow}");

                        // Optionally log activities to a file
                        File.AppendAllText("WorkActivityLog.txt", $"[{timestamp}] {currentUser}: {activeWindow}\n");
                    }

                    Thread.Sleep(5000); // Log every 5 seconds
                }
            });

            backgroundThread.IsBackground = true; // Ensure thread stops if the application exits
            backgroundThread.Start();
        }

        static void ViewLogs()
        {
            Console.Clear();
            Console.WriteLine("View Logs");

            Console.WriteLine("Log In/Out Records:");
            foreach (var record in logInOutRecords)
            {
                Console.WriteLine(record);
            }

            Console.WriteLine("\nWork Activity Records:");
            foreach (var record in workActivityRecords)
            {
                Console.WriteLine(record);
            }

            Console.ReadLine();
        }
    }
}