﻿
using System;

class SimpleCalculator
{
    static void Main()
    {
        Console.WriteLine("");
        Console.WriteLine("  ◆ Welcome to Simple Calculator! ◆");

        // Get the first number
        Console.Write("  ♠︎ Enter the first number: ");
        double firstNumber = Convert.ToDouble(Console.ReadLine());


        // Get the second number
        Console.Write("  ♠︎ Enter the second number: ");
        double secondNumber = Convert.ToDouble(Console.ReadLine());


        // Get the operation
        Console.Write("  ♠︎ Enter the operation [+] [-] [*] [/]: ");
        char operation = Convert.ToChar(Console.ReadLine());


        // Perform the calculation
        double result = 0;
        bool validOperation = true;

        if (operation == '+')
        {
            result = firstNumber + secondNumber;
        }
        else if (operation == '-')
        {
            result = firstNumber - secondNumber;
        }
        else if (operation == '*')
        {
            result = firstNumber * secondNumber;
        }
        else if (operation == '/')
        {
            result = firstNumber / secondNumber;
        }
        else
        {
            Console.WriteLine("    》Invalid operation");
            validOperation = false;
        }

        // Display the result only if the operation was valid
        if (validOperation)
        {
            Console.WriteLine($"    》The result of {firstNumber} {operation} {secondNumber} is {result}.");
        }
    }
}


