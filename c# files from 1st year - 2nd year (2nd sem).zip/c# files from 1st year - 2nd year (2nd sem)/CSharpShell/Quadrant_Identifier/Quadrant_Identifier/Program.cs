﻿using System;
using System.Linq;

namespace Quadrant_Identifier;

public static class Program
{
	public static void Main()
	{
    Console.WriteLine("        ♡♡♡♡♡ QUADRANT IDENTIFIER ♡♡♡♡♡");
	Console.WriteLine("");
	
	// Prompt the user to input the value of x and y
	Console.WriteLine("  Please input a value for x and y below.");
	Console.Write("  x: ");
	int x = Convert.ToInt32(Console.ReadLine());
	Console.Write("  y: ");
	int y = Convert.ToInt32(Console.ReadLine());
	
	// Determine and print the quadrant of the point
	if (x > 0 && y > 0)
	{
       Console.WriteLine("");
	   Console.WriteLine("  The point " + "(" + x + ", " + y + ")" + " lies in the first quadrant. " );
    }
	
	else if (x < 0 && y > 0)
	{
       Console.WriteLine("");
	   Console.WriteLine("  The point " + "(" + x + ", " + y + ")" + " lies in the second quadrant. " );
    }
	
	else if (x < 0 && y < 0)
	{
       Console.WriteLine("");
	   Console.WriteLine("  The point " + "(" + x + ", " + y + ")" + " lies in the third quadrant. " );
    }
	
	else if (x > 0 && y < 0)
	{
       Console.WriteLine("");
	   Console.WriteLine("  The point " + "(" + x + ", " + y + ")" + " lies in the fourth quadrant. " );
    }
	
	else if (x == 0 && y == 0)
	{
       Console.WriteLine("");
	   Console.WriteLine("  The point " + "(" + x + ", " + y + ")" + " lies on the origin. " );
    }
	
	else if (x == 0)
	{
       Console.WriteLine("");
	   Console.WriteLine("  The point " + "(" + x + ", " + y + ")" + " lies on the y-axis. " );
    }
	
	else if (y == 0)
	{
       Console.WriteLine("");
	   Console.WriteLine("  The point " + "(" + x + ", " + y + ")" + " lies on the x-axis. " );
    }
	
	else
	{
       Console.WriteLine("");
	   Console.WriteLine("  Invalid value. Please try again. :>");
    }
	
	
	
	
	Console.WriteLine("");
	Console.WriteLine("");
	Console.WriteLine("");
	Console.WriteLine("        《《《《《 MATH IS LIFE 》》》》》");
	}
}
