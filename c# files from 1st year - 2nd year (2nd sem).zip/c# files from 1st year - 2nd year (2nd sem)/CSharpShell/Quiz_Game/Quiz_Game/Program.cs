﻿using System;
using System.Linq;

namespace Quiz_Game;

public static class Program
{
	public static void Main()
	{
    Console.WriteLine("--- Welcome to Ka-Pinoy Game! ---");
	Console.WriteLine("");
	
	Console.WriteLine("Please choose from any of the numbers for your question and enter below. Remember! You only have 5 lives so answer carefully. Good Luck!");
	Console.WriteLine("");
	
	Console.WriteLine(" [1] Easy ");
	Console.WriteLine(" [2] Easy ");
	Console.WriteLine(" [3] Moderate ");
	Console.WriteLine(" [4] Moderate ");
	Console.WriteLine(" [5] Hard ");
	
	
	Console.WriteLine("");
	Console.Write("Enter number: ");
	
	string correctAnswer = "Jollibee";
	string answer;
	string lives;
	
	
	while (lives > 0)
	{
        Console.WriteLine("");
		Console.WriteLine("Ano paboritong fast food restaurant ng mga bata? ");
		Console.Write("Answer: ");
		answer = Console.ReadLine();
		
		if (answer.Equals(correctAnswer))
		{
            Console.WriteLine("Tama! You got the correct answer!");
			break;
        }
		
		else lives;
		
		if(lives==0) Console.WriteLine("Game Over");
        
		
    }
	
	}
}
