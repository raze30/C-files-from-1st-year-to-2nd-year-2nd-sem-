﻿using System;
using System.Linq;
using CSharpShellCore;

namespace Exer2_Machine_Prob;

public static class Program
{
	public static void Main()
	{
    Console.WriteLine("--- HELLO! KINDLY INPUT YOUR INFORMATION BELOW. THANK YOU! :> ---");
	
	Console.WriteLine("");
	Console.Write("Name: ");
	string name = Console.ReadLine();
	
	Console.Write("Year Level: ");
	string yearlevel = Console.ReadLine();
	
	Console.Write("Section: ");
	string section = Console.ReadLine();
	
	Console.WriteLine("");
	Console.Write("Prelim Grade: ");
	int pgrade = Convert.ToInt32(Console.ReadLine());
	Console.Write("Midterm Grade: ");
	int mgrade = Convert.ToInt32(Console.ReadLine());
	Console.Write("Final Grade: ");
	int fgrade = Convert.ToInt32(Console.ReadLine());
	
	int grade = (pgrade + mgrade + fgrade)/3;
	
	if (grade >= 75)
	{
        Console.WriteLine("");
        Console.WriteLine("Your Average Grade is " + grade + ". Congratulations! You passed. Keep up the consistency, brother.");
		Console.WriteLine("");
    }
	
	if (grade <= 74)
	{
        Console.WriteLine("");
		Console.WriteLine("Your Average Grade is " + grade + ". Oh no! You failed. Better focus more on your tasks.");
	
	}
}
}