﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Text;

class GasolineStore
{
    static void Main(string[] args)
    {
        // Username and password for login
        string correctUsername = "wizard";
        string correctPassword = "gas";
        bool loggedIn = false;
        int attempt = 0;

        // Centered header with decorative symbols
        Console.WriteLine("     ╔════════════════════════════════════════════════════════════════════╗");
        Console.WriteLine("     ║                    Welcome to the Gasoline Wizard!                 ║");
        Console.WriteLine("     ╚════════════════════════════════════════════════════════════════════╝");
        Console.WriteLine("     ----------------------------------------------------------------------");

        // Attempt login with a maximum of 3 tries
        do
        {
            attempt++;

            Console.WriteLine("                     ╔═══════════════════════════════════╗");
            Console.WriteLine("                     ║       Login to your Account       ║");
            Console.WriteLine("                     ╚═══════════════════════════════════╝");
            
            Console.Write("		            ➤  Username: ");
            string username = Console.ReadLine();

            Console.Write("		            ➤  Password: ");
            string password = Console.ReadLine();
            Console.WriteLine("                     ═════════════════════════════════════");

            if (username == correctUsername && password == correctPassword)
            {
                Console.WriteLine("                             ✔  Login Successful!");
                Console.WriteLine($"                      Welcome to Gasoline Wizard, {username}! ");
                loggedIn = true;
                break;
            }
            else
            {
                Console.WriteLine("                      ✖  Incorrect Username or Password.");
                Console.WriteLine("");
                if (attempt >= 3)
                {
                    Console.WriteLine("                  ===========================================");
                    Console.WriteLine("                 ✖  Too many failed login attempts. Exiting...");
                    Console.WriteLine("");
                    return; // Exit if login failed
                }
            }
        }

        while (!loggedIn);


        // Define arrays for price calculations for liters 1 through 20, and additional arrays for half-liter
        string[][] literArrays = new string[20][];
        string[][] halfLiterArrays = new string[20][];

        // Price calculation for 70 pesos per liter 
        literArrays[0] = new string[] { "1000     -     70    =     930", "500      -     70    =     430", "200      -     70    =     130", "100      -     70    =     30" };
        literArrays[1] = new string[] { "1000     -     140   =     860", "500      -     140   =     360", "200      -     140   =     60", "150      -     140   =     10" };
        literArrays[2] = new string[] { "1000     -     210   =     790", "500      -     210   =     290", "400      -     210   =     190", "300      -     210   =     90", "250      -     210   =     40", "220      -     210   =     10" };
        literArrays[3] = new string[] { "1000     -     280   =     720", "500      -     280   =     220", "400      -     280   =     120", "300      -     280   =     20", "290      -     280   =     10" };
        literArrays[4] = new string[] { "1000     -     350   =     650", "500      -     350   =     150", "400      -     350   =     50", "360      -     350   =     10" };
        literArrays[5] = new string[] { "1000     -     420   =     580", "600      -     420   =     180", "500      -     420   =     80", "450      -     420   =     30" };
        literArrays[6] = new string[] { "1000     -     490   =     510", "600      -     490   =     110", "500      -     490   =     10" };
        literArrays[7] = new string[] { "1000     -     560   =     440", "700      -     560   =     140", "600      -     560   =     40", "570      -     560   =     10" };
        literArrays[8] = new string[] { "1000     -     630   =     370", "800      -     630   =     170", "700      -     630   =     70", "650      -     630   =     20", "640      -     630   =     10" };
        literArrays[9] = new string[] { "1000     -     700   =     300", "800      -     700   =     100" };
        literArrays[10] = new string[] { "1000     -     770   =     230","900      -     770   =     130", "800      -     770   =     100", "780      -     770   =     10" };
        literArrays[11] = new string[] { "1000     -     840   =     160", "900      -     840   =     60", "850      -     840   =     10" };
        literArrays[12] = new string[] { "1000     -     910   =     90", "950      -     910   =     40", "920      -     910   =     10"};
        literArrays[13] = new string[] { "1000     -     980   =     20", "990      -     980   =     10" };
        literArrays[14] = new string[] { "2000     -     1050   =     950", "1500     -     1050   =     450", "1200     -     1050   =     150", "1180     -     1050   =     50" };
        literArrays[15] = new string[] { "2000     -     1120   =     880", "1500     -     1120   =     380", "1200     -     1120   =     80", "1150     -     1120   =     30", "1140     -     1120   =     20" };
        literArrays[16] = new string[] { "2000     -     1190   =     810", "1500     -     1190   =     310", "1200     -     1190   =     10" };
        literArrays[17] = new string[] { "2000     -     1260   =     740", "1500     -     1260   =     240", "1400     -     1260   =     140", "1380     -     1260   =     40", "1270     -     1260   =     10" };
        literArrays[18] = new string[] { "2000     -     1330   =     670", "1500     -     1330   =     170", "1400     -     1330   =     70", "1350     -     1330   =     20", "1340     -     1330   =     10" };
        literArrays[19] = new string[] { "2000     -     1400   =     600", "1500     -     1400   =     100" };

        halfLiterArrays[0] = new string[] { "1000     -     105   =     895", "500      -     105   =     395", "200      -     105   =     95", "150      -     105   =     45", "120      -     105   =     15", "110      -     105   =     5" };
        halfLiterArrays[1] = new string[] { "1000     -     175   =     825", "500      -     175   =     325", "200      -     175   =     25", "190      -     175   =     15", "180      -     175   =     5" };
        halfLiterArrays[2] = new string[] { "1000     -     245   =     755", "500      -     245   =     255", "300      -     245   =     55", "260      -     245   =     15", "250      -     245   =     10" };
        halfLiterArrays[3] = new string[] { "1000     -     315   =     685", "500      -     315   =     185", "400      -     315   =     85", "350      -     315   =     35", "320      -     315   =     5" };
        halfLiterArrays[4] = new string[] { "1000     -     385   =     615", "500      -     385   =     115", "400      -     385   =     15", "390      -     385   =     5" };
        halfLiterArrays[5] = new string[] { "1000     -     455   =     545", "600      -     455   =     145", "500      -     455   =     45", "470      -     455   =     15", "460      -     455   =     5" };
        halfLiterArrays[6] = new string[] { "1000     -     525   =     475", "700      -     525   =     175", "600      -     525   =     75", "550      -     525   =     25", "540      -     525   =     15", "530      -     525   =     5" };
        halfLiterArrays[7] = new string[] { "1000     -     595   =     405", "700      -     595   =     105", "600      -     595   =     5" };
        halfLiterArrays[8] = new string[] { "1000     -     665   =     335", "800      -     665   =     135", "700      -     665   =     35", "680      -     665   =     15", "670      -     665   =     5" };
        halfLiterArrays[9] = new string[] { "1000     -     735   =     265", "900      -     735   =     165", "800      -     735   =     65", "750      -     735   =     15", "740      -     735   =     5" };
        halfLiterArrays[10] = new string[] { "1000     -     805   =     195", "900      -     805   =     95", "850      -     805   =     45", "820      -     805   =     15", "810      -     805   =     5" };
        halfLiterArrays[11] = new string[] { "1000     -     875   =     125", "900      -     875   =     25", "880      -     875   =     5" };
        halfLiterArrays[12] = new string[] { "1000     -     945   =     55", "960      -     945   =     15", "950      -     945   =     5" };
        halfLiterArrays[13] = new string[] { "2000     -     1015   =     985", "1500     -     1015   =     485", "1200     -     1015   =     185", "1100     -     1015   =     85", "1050     -     1015   =     35", "1020     -     1015   =     5" };
        halfLiterArrays[14] = new string[] { "2000     -     1085   =     915", "1500     -     1085   =     415", "1200     -     1085   =     115", "1100     -     1085   =     15", "1090     -     1085   =     5" };
        halfLiterArrays[15] = new string[] { "2000     -     1155   =     845", "1500     -     1155   =     345", "1200     -     1155   =     45", "1170     -     1155   =     15", "1160     -     1155   =     5" };
        halfLiterArrays[16] = new string[] { "2000     -     1225   =     775", "1500     -     1225   =     275", "1400     -     1225   =     175", "1300     -     1225   =     75", "1250     -     1225   =     25", "1230     -     1225   =     5" };
        halfLiterArrays[17] = new string[] { "2000     -     1295   =     705", "1500     -     1295   =     205", "1400     -     1295   =     105", "1300     -     1295   =     5" };
        halfLiterArrays[18] = new string[] { "2000     -     1365   =     635", "1500     -     1365   =     135", "1400     -     1365   =     35", "1380     -     1365   =     15", "1370     -     1365   =     5" };
        halfLiterArrays[19] = new string[] { "2000     -     1435   =     565", "1500     -     1435   =     65", "1450     -     1435   =     15", "1440     -     1435   =     5" };

        // Initialize transaction count and lists to track valid transactions and amounts
        List<string> validTransactions = new List<string>();
        double totalLiters = 0;
        int totalAmount = 0;

        // Display initial instructions with decorative elements
        Console.WriteLine("");
        Console.WriteLine("");
        Console.WriteLine("     ◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇");
        Console.WriteLine("     ╔════════════════════════════════════════════════════════════════════╗");
        Console.WriteLine("     ║                         》Gasoline Wizard 《                       ║");
        Console.WriteLine("     ║                  Automated Gasoline Price Calculator               ║");
        Console.WriteLine("     ║                1 liter: 70 pesos, 1/2 liter: 35 pesos              ║");
        Console.WriteLine("     ║                Input 1-20 for liters, add '+' for 1/2              ║");
        Console.WriteLine("     ║                      Enter '0' to end program                      ║");
        Console.WriteLine("     ╚════════════════════════════════════════════════════════════════════╝");
        Console.WriteLine("     ◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇");


        // Main loop for processing user input with a decorative touch
        while (true) // Loop indefinitely until user decides to stop
        {
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("     ----------------------------------------------------------------------");
            Console.Write("                            ➤  Input the liter value: "); // Prompt for user input
            string userInput = Console.ReadLine();
            Console.WriteLine("     ----------------------------------------------------------------------");
            Console.WriteLine("                                 ◆   ◆   ◆   ◆");
            Console.WriteLine("                                 ◆   ◆   ◆   ◆");

            if (userInput == "0") // End the program early
            {
                Console.WriteLine("     ----------------------------------------------------------------------");
                Console.WriteLine("                      Transaction stopped early. Exiting...");
                Console.WriteLine("");
                break;
            }

            bool isHalfLiter = userInput.EndsWith("+"); // Check for a half-liter
            string inputWithoutPlus = isHalfLiter ? userInput.TrimEnd('+') : userInput;

            int literChoice;
            bool validInput = int.TryParse(inputWithoutPlus, out literChoice);

            if (!validInput || literChoice < 1 || literChoice > 20)
            {
                Console.WriteLine("             ✖  Invalid input. Please enter a number between 1 and 20.");
                continue;
            }

            validTransactions.Add(userInput); // Store the transaction
            totalLiters += literChoice + (isHalfLiter ? 0.5 : 0); // Total liters
            int literAmount = 70 * literChoice; // Full liter amount
            int halfLiterAmount = isHalfLiter ? 35 : 0; // Half-liter cost
            totalAmount += literAmount + halfLiterAmount; // Accumulate total amount

            // Display calculations with a decorative header
            Console.WriteLine("            ╔════════════════════════════════════════════════════════╗");

            string header = isHalfLiter ? $"            ◇ Displaying Calculations for {literChoice} Liter/s with half-liter  ◇" : $"            ◇          Displaying Calculations for {literChoice} Liter/s         ◇";
            Console.WriteLine(header);

            Console.WriteLine("            ╚════════════════════════════════════════════════════════╝");

            string[] selectedArray = isHalfLiter ? halfLiterArrays[literChoice - 1] : literArrays[literChoice - 1];

            foreach (string item in selectedArray)
            {
                Console.WriteLine($"                         • {item}");
            }
            Console.WriteLine("             ═══════════════════════════════════════════════════════");

        }

        // Summary at the end with valid transactions, total liters, and total amount

            // Calculate the maximum length for each line (this is for the design of the system)
            int maxTransactionLength = validTransactions.Max(t => $"            ◆           • {t} ◆".Length);
            int maxTotalLitersLength = $"            ◆           Total liters sold: {totalLiters.ToString("#.0")} ◆".Length;
            int maxTotalAmountLength = $"            ◆           Total amount in pesos: ₱ {totalAmount}                ◆".Length;

            // Determine the overall maximum length
            int maxLength = Math.Max(maxTransactionLength, Math.Max(maxTotalLitersLength, maxTotalAmountLength));

        Console.WriteLine("            ╔════════════════════════════════════════════════════════╗");
        Console.WriteLine($"            ◆     Here's a summary of your valid transactions:       ◆");

        // Display valid transactions
        foreach (string transaction in validTransactions)
        {
            Console.WriteLine($"            ◆           • {transaction.PadRight(maxLength - 28)} ◆");
        }

        // Display total liters sold
        Console.WriteLine($"            ◆           Total liters sold: {totalLiters.ToString("#.0").PadRight(maxLength - 45)} ◆");

        // Display total amount in pesos
        Console.WriteLine($"            ◆           Total amount in pesos: ₱ {totalAmount.ToString().PadRight(maxLength - 51)} ◆");

        Console.WriteLine("            ╚════════════════════════════════════════════════════════╝");

        Console.WriteLine("");
        Console.WriteLine($"             Thank you for using the Gasoline Wizard. Goodbye, {correctUsername}!");
        Console.WriteLine("");
        Console.WriteLine("");

    }
}