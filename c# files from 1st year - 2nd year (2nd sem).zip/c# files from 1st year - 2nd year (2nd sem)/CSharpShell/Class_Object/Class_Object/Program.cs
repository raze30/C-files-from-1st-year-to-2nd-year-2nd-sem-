﻿using System;

namespace ClassObject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write(" Enter Last Name: ");
            string lname = Console.ReadLine();

            Console.Write(" Enter First Name: ");
            string fname = Console.ReadLine();

            Console.Write(" Enter Middle Name: ");
            string mname = Console.ReadLine();

            Console.Write(" Enter Course: ");
            string course = Console.ReadLine();

            Console.Write(" Enter Year: ");
            int year = Convert.ToInt32(Console.ReadLine());

            Console.Write(" Enter Section: ");
            string section = Console.ReadLine();

            Console.Write(" Enter Midterm Grade: ");
            float mGrade = float.Parse(Console.ReadLine());

            Console.Write(" Enter Final Grade: ");
            float fGrade = float.Parse(Console.ReadLine());

            Students s1 = new Students(lname, fname, mname, course, year, section, mGrade, fGrade);
            s1.Information();
            s1.SemestralGrades();
            Console.WriteLine();
        }

        class Students
        {
            public string Lname, Fname, Mname;
            public int year;
            public string course, section;
            public float mGrade, fGrade;

            public Students(
                string Lname,
                string Fname,
                string Mname,
                string course,
                int year,
                string section,
                float mGrade,
                float fGrade
            )

            {
                this.Lname = Lname;
                this.Fname = Fname;
                this.Mname = Mname;
                this.course = course;
                this.year = year;
                this.section = section;
                this.mGrade = mGrade;
                this.fGrade = fGrade;
            }

            public void Information()
            {
                Console.WriteLine(" ------------------------");
                Console.WriteLine(" Hi! My name is: " + Lname + ", " + Fname + " " + Mname);
                Console.WriteLine();
                Console.WriteLine(" Course : " + course);
                Console.WriteLine(" Year : " + year);
                Console.WriteLine(" Section : " + section);
                Console.WriteLine();
            }

            public void SemestralGrades()
            {
                float average = (mGrade + fGrade) / 2;
                Console.WriteLine(" Average Grade: " + average);
                if (average > 100)
                {
                    Console.WriteLine(" Invalid Grade");
                    Console.WriteLine(" -----------------------");
                }
                else if (average >= 99)
                {
                    Console.WriteLine(" Excellent");
                    Console.WriteLine(" -----------------------");
                }
                else if (average >= 90)
                {
                    Console.WriteLine(" Very Good");
                    Console.WriteLine(" -----------------------");
                }
                else if (average >= 81)
                {
                    Console.WriteLine(" Above Average");
                    Console.WriteLine(" -----------------------");
                }
                else if (average >= 78)
                {
                    Console.WriteLine("Average");
                    Console.WriteLine(" -----------------------");
                }
                else if (average >= 75)
                {
                    Console.WriteLine(" Passed");
                    Console.WriteLine(" -----------------------");
                }
                else
                {
                    Console.WriteLine(" Failed");
                    Console.WriteLine(" -----------------------");
                }
            }
        }
    }
}