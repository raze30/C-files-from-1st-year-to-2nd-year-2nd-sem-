﻿using System;

namespace Movie;

public static class Program
{
    public static void Main(string[] args)
    {
        Movie movie1 = new("Mr. Bean", "Comedy", "P");
        Movie movie2 = new("Alchemy of Souls", "Korean Drama", "PG-13");
        Movie movie3 = new("Mission Impossible: Ghost Protocol", "Action", "SPG");

        Console.WriteLine("Name: " + movie1.Name);
        Console.WriteLine("Category: " + movie1.Category);
        Console.WriteLine("Rate: " + movie1.Rate);
        Console.WriteLine("----------------------------");

        Console.WriteLine("Name: " + movie2.Name);
        Console.WriteLine("Category: " + movie2.Category);
        Console.WriteLine("Rate: " + movie2.Rate);
        Console.WriteLine("----------------------------");

        Console.WriteLine("Name: " + movie3.Name);
        Console.WriteLine("Category: " + movie3.Category);
        Console.WriteLine("Rate: " + movie3.Rate);
        Console.WriteLine("----------------------------");



    }
}



public class Movie
{
    public string Name { set; get; }
    public string Category { set; get; }
    public string Rate { set; get; }

    public Movie(string name, string category, string rate)
    {
        Name = name;
        Category = category;
        Rate = rate;
    }
}
