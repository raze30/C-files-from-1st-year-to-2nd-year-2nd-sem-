﻿using System;

class GasolineStore
{
    static void Main(string[] args)
    {
            
		Console.WriteLine("  ♧♣︎♧ Automated Price Calculation System ♧♣︎♧");
		Console.WriteLine("");
		
        // Define the arrays with prices for liter 1 and liter 2
        string[] liter1 = { "1000 - 70 = 930", "500 - 70 = 430", "200 - 70 = 130", "100 - 70 = 30", "80 - 70 = 10" };
        string[] liter2 = { "1000 - 140 = 860", "500 - 140 = 360", "200 - 140 = 60", "150 - 140 = 10" };

        Console.Write("   Input the liter/s: ");
        int userInput = int.Parse(Console.ReadLine());

        if (userInput == 1)
        {
            Console.WriteLine("");
			Console.WriteLine("        ◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆ ");
			Console.WriteLine("");
            Console.WriteLine("   Displaying Calculations for 1 liter:");
            for (int i = 0; i < liter1.Length; i++)
            {
                Console.WriteLine("");
                Console.WriteLine("   " + liter1[i]);
            }
        }
        else if (userInput == 2)
        {
            Console.WriteLine("");
			Console.WriteLine("        ◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆ ");
			Console.WriteLine("");
            Console.WriteLine("   Displaying calculations for 2 liters:");
            for (int i = 0; i < liter2.Length; i++)
            {
                Console.WriteLine("");
                Console.WriteLine("   " + liter2[i]);
            }
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter 1 or 2.");
        }
    }
}