﻿using System;
using System.Linq;

namespace Body_Mass_Index;

public static class Program
{
	public static void Main()
	{	
		Console.WriteLine("          ◇◇◇◇◇ BODY MASS INDEX ◇◇◇◇◇");
		Console.WriteLine("");
		Console.WriteLine(" Kindly input your weight and height below. ");
		Console.WriteLine("");
		
        // Prompt the user to enter weight in kilograms
        Console.Write(" Input your weight in kilograms: ");
        double weight = Convert.ToDouble(Console.ReadLine());

        // Prompt the user to enter height in meters
        Console.Write(" Input your height in meters: ");
        double height = Convert.ToDouble(Console.ReadLine());

        // Calculate BMI using the formula BMI = weight / (height * height)
        double bmi = weight / (height * height);

        // Print the calculated BMI
        Console.WriteLine(" Your BMI is: " + bmi);

        // Determine the BMI category
        if (bmi < 18.5)
        {
            Console.WriteLine("");
            Console.WriteLine(" 》You are underweight.");
            if (bmi < 16)
            {
                Console.WriteLine(" 》You are severely underweight.");
            }
            else
            {
                Console.WriteLine(" 》You are mildly to moderately underweight.");
            }
        }
        else if (bmi >= 18.5 && bmi <= 24.9)
        {
            Console.WriteLine("");
            Console.WriteLine(" 》You have a normal weight.");
        }
        else if (bmi >= 25 && bmi <= 29.9)
        {
            Console.WriteLine("");
            Console.WriteLine(" 》You are overweight.");
            if (bmi < 27.5)
            {
                Console.WriteLine(" 》You are pre-obese.");
            }
            else
            {
                Console.WriteLine(" 》You are obese class I.");
            }
        }
        else if (bmi >= 30)
        {
            Console.WriteLine("");
            Console.WriteLine(" 》You are obese.");
            if (bmi < 35)
            {
                Console.WriteLine(" 》You are obese class II.");
            }
            else
            {
                Console.WriteLine(" 》You are obese class III.");
            }	
		}
		
		
		
		
		
		Console.WriteLine("");
		Console.WriteLine("");	
		Console.WriteLine("");
		Console.WriteLine("          《《《《《 THANK YOU 》》》》》");
	}
}



