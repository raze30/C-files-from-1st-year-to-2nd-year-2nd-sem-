﻿using System;
using System.Linq;
using CSharpShellCore;

namespace Age_Identification;

public static class Program
{
	public static void Main()
	{
    Console.WriteLine("--- HELLO, KINDLY INPUT YOUR AGE BELOW :> ---");
	Console.WriteLine("");
	Console.Write("Age: ");
	int age = Convert.ToInt32(Console.ReadLine());
	
	if (age >= 24)
	{
        Console.WriteLine("");
        Console.WriteLine("You are an adult. Live a good life and hold on a better future.");
		Console.WriteLine("");
	}
	
	else if (age >= 18)
	{
        Console.WriteLine("");
        Console.WriteLine("You are a young adult. I suggest you start preparing for your future.");
		Console.WriteLine("");
	}
	
    else if (age >= 13)
	{
        Console.WriteLine("");
        Console.WriteLine("You are a teenager. Enjoy life as this is the best opportunity to do so.");
		Console.WriteLine("");
	}
	
	else if (age >= 4)
	{
        Console.WriteLine("");
        Console.WriteLine("You are still a kid. Please spend time with your parents, you will learn a lot from them.");
		Console.WriteLine("");
	}
	
	else if (age >= 1)
	{
        Console.WriteLine("");
        Console.WriteLine("You are still baby. Cherish yòur new life.");
		Console.WriteLine("");
	}
	
	else 
	{
        Console.WriteLine("");
        Console.WriteLine("Invalid gge. Please input again. Thank you.");
		Console.WriteLine("");
	}
	
	}
	
}
