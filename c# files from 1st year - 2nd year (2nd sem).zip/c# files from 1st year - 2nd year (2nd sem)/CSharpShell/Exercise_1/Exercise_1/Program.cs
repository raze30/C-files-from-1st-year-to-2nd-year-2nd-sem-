﻿using System;
using System.Linq;

namespace Exercise_1;

public static class Program
{
    public static void Main()
    {

        String name = "Rayyan Mentang";
        int age = 21;
        double gpa = 1.50;
        char gender = 'M';


        Console.WriteLine("");
        Console.WriteLine(" Hi, My name is " + name);
        Console.WriteLine(" I am " + age + " years old.");
        Console.WriteLine(" My GPA is " + gpa);
        Console.WriteLine(" My Gender is " + gender);

    }
}
