﻿using System;
using System.Linq;

namespace Codename_and_Password;

public static class Program
{
	public static void Main()
	{
       string name;
	   string password;
	   
	   
	   Console.Write("Enter your Codename: ");
	   name = Console.ReadLine();
	   
	   Console.Write("Enter your Password: ");
	   password = Console.ReadLine();
	   
	   if ((name == "SkullzKiller") && password == ("hello123"))
	   {
           Console.WriteLine("");
		   Console.WriteLine("Thank you! You have logged in successfully in the game!");
		   Console.WriteLine("");
	   }
	   	   
	   else
	   {
           Console.WriteLine("");
		   Console.WriteLine("You have input an incorrect Codename/Password.");  
		   Console.WriteLine("");     
	   }
	   
	   
	   
	}
}
