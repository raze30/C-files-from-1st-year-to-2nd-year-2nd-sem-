﻿

using System;

class Animal
{
    public Animal()
    {
        Console.WriteLine("Animal Constructor");
    }
}

class Dragon : Animal
{
    public Dragon() : base()  // Calls the Animal constructor
    {
        Console.WriteLine("Dragon Constructor");
    }

    public Dragon(string name) : this()  // Calls the default Dog constructor
    {
        Console.WriteLine("Dragon Constructor with name: " + name);
    }

    public Dragon(string name, int age) : this(name)  // Calls the Dog(string name) constructor
    {
        Console.WriteLine("Dragon Constructor with name: " + name + " and age: " + age);
    }
}

class Program
{
    static void Main()
    {
        // Create a Dog object using the constructor with name and age
        Dragon dog = new Dragon("Dracarys", 200);
    }
}