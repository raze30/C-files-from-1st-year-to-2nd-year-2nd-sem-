﻿using System;
using System.Linq;

namespace Machine_Prob_2;

public static class Program
{
	public static void Main()
	{
    Console.WriteLine("")
	
	
	}
}
