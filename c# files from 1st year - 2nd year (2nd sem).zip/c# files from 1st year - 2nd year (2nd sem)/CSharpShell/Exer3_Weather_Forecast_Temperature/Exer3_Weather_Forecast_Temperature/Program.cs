﻿using System;
using System.Linq;
using CSharpShellCore;

namespace Exer3_Weather_Forecast_Temperature;

public static class Program
{
	public static void Main()
	{
    Console.WriteLine(">>>> WEATHER FORECAST TEMPERATURE <<<<");
	Console.WriteLine("");
	
	//Input Type of Temperature 
	Console.WriteLine("Choose the temperature you want.");
	Console.WriteLine("Input 1 for degrees Celsius or 2 for degrees Farenheit.");
	Console.WriteLine("");
	Console.Write("Input type of temperature: ");
	int temp = Convert.ToInt32(Console.ReadLine());
	string celsius = "Celsius";
	string fahrenheit = "Fahrenheit";
	
	if (temp == 1)
	{	
		Console.WriteLine("You have chosen degrees " + celsius + ".");
		Console.WriteLine("");
    }
	
	else if (temp == 2)
	{	
        Console.WriteLine("You have chosen degrees " + fahrenheit + ".");
		Console.WriteLine("");
    }
	
	//Input Temperature and Weather Condition
	Console.Write("Input the temperature: ");
	int weathertemp = Convert.ToInt32(Console.ReadLine());
	
	Console.Write("Input the weather condition: ");
	string weather = Console.ReadLine();
	
	if ((weathertemp <= 90 && weathertemp >= 70) && weather == "sunny")
	{	
        Console.WriteLine("");
		Console.WriteLine("Stay hydrated! The sun's out in full force today.");
    }
	
	else if ((weathertemp <= 32 && weathertemp >= 21) && weather == "sunny")
	{	
        Console.WriteLine("");
		Console.WriteLine("Stay hydrated! The sun's out in full force today.");
    }
	
	else if ((weathertemp <= 70 && weathertemp >= 50) && weather == "rainy")
	{
		Console.WriteLine("");
		Console.WriteLine("Stay dry! It's raining outside.");
    }
	
	else if ((weathertemp <= 21 && weathertemp >= 10) && weather == "rainy")
	{	
        Console.WriteLine("");
		Console.WriteLine("Stay dry! It's raining outside. ");
    }
	
	else if (weathertemp <= 32 && weather == "snowy")
	{	
        Console.WriteLine("");
		Console.WriteLine("Watch your step. It's snowing heavily. ");
    }
	
	else if ((weathertemp <= 70 && weathertemp >= 50) && weather == "cloudy")
	{	
        Console.WriteLine("");
		Console.WriteLine("Stay cozy! It's cloudy and cool outside.");
    }
	
	else if ((weathertemp <= 21 && weathertemp >= 10) && weather == "cloudy")
	{	
        Console.WriteLine("");
		Console.WriteLine("Stay cozy! It's cloudy and cool outside.");
    }
	
	}
}
