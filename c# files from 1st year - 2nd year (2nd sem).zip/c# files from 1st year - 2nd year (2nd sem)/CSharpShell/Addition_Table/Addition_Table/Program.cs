﻿using System;
using System.Linq;

namespace Addition_Table;

public static class Program
{
	public static void Main()
	{
            
    Console.WriteLine("          ♧♧♧♧♧ ADDITION TABLE ♧♧♧♧♧");
	Console.WriteLine("");
	
	// Prompt the user to input a number
	Console.Write("   Input a number: ");
	int number = Convert.ToInt32(Console.ReadLine());
	Console.WriteLine("");

	// Calculate and print the Addition Table
	int i = 1;
	while (i <= 10)
	{
        int result = number + i;
        Console.WriteLine("   " + number + " + " + i + " = " + result );
		i++;
    }
	
	
	
	Console.WriteLine("");
	Console.WriteLine("");
	Console.WriteLine("");
	Console.WriteLine("          《《《《《 MATH IS LIFE 》》》》》");
	}
}
